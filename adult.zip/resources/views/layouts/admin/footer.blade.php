<footer class="main-footer">
    <div class="pull-right hidden-xs">
    <b>Version</b> 2.3.3
    </div>
    <strong>Copyright &copy; 2017 <a href="{{Setting::get('copyrights_url') ? Setting::get('copyrights_url') : url('/')}}">{{Setting::get('site_name' , 'Stream Hash')}}</a>.</strong> All rights
    reserved.
</footer>