<?php $__env->startSection('title', tr('add_video')); ?>

<?php $__env->startSection('content-header', tr('add_video')); ?>

<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('admin-css/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin-css/plugins/iCheck/all.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-video-camera"></i> <?php echo e(tr('add_video')); ?></li>
<?php $__env->stopSection(); ?> 


<?php if(checkSize()): ?>
<div class="alert alert-warning">
    <button type="button" class="close" data-dismiss="alert">×</button>
        <?php echo e(tr('max_upload_size')); ?> <b><?php echo e(ini_get('upload_max_filesize')); ?></b>&nbsp;&amp;&nbsp;<?php echo e(tr('post_max_size')); ?> <b><?php echo e(ini_get('post_max_size')); ?></b>
</div>
<?php endif; ?>


<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-12">

            <div class="box box-info">

                <div class="box-header">
                </div>

                <form class="form-horizontal" id="video-upload" action="<?php echo e(route('admin.save.video')); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <div class="col-md-6">

                            <div class="form-group">
                                <label for="title" class=""><?php echo e(tr('title')); ?></label>
                                <input type="text" required class="form-control" id="title" name="title" placeholder="<?php echo e(tr('title')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="description" class=""><?php echo e(tr('description')); ?></label>
                                <textarea  style="overflow:auto;resize:none" class="form-control" required rows="4" cols="50" id="description" name="description"></textarea>
                            </div>
                            
                            <div class="form-group">

                                <label for="category" class=""><?php echo e(tr('select_category')); ?></label>

                                <select id="category" required name="category_id" class="form-control">
                                    <option value=""><?php echo e(tr('select_category')); ?></option>

                                    <?php if(count($categories) > 0): ?>
                                        <?php foreach($categories as $category): ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>

                                </select>

                            </div>

                            <div class="form-group">

                                <label for="sub_category" class=""><?php echo e(tr('select_sub_category')); ?></label>

                                <select id="sub_category" required name="sub_category_id" class="form-control" disabled>
                                    <option value=""><?php echo e(tr('select_sub_category')); ?></option>
                                </select>
                            
                            </div>

                            <div class="form-group">

                                <label for="genre" class=""><?php echo e(tr('select_genre')); ?></label>

                                <select id="genre" name="genre_id" class="form-control" disabled>
                                    <option value=""><?php echo e(tr('select_genre')); ?></option>
                                </select>
                            </div>

                            

                            <div class="form-group">
                                <label for="ratings" class=""><?php echo e(tr('ratings')); ?></label>
                                <span class="starRating">
                                    <input id="rating5" type="radio" name="ratings" value="5">
                                    <label for="rating5">5</label>

                                    <input id="rating4" type="radio" name="ratings" value="4">
                                    <label for="rating4">4</label>

                                    <input id="rating3" type="radio" name="ratings" value="3">
                                    <label for="rating3">3</label>

                                    <input id="rating2" type="radio" name="ratings" value="2">
                                    <label for="rating2">2</label>

                                    <input id="rating1" type="radio" name="ratings" value="1">
                                    <label for="rating1">1</label>
                                </span>
                            </div>

                            <div class="form-group">
                                <label for="reviews" class=""><?php echo e(tr('reviews')); ?></label>
                                <textarea  style="overflow:auto;resize:none" class="form-control" required rows="4" cols="50" id="reviews" name="reviews"></textarea>
                            </div>
                        </div>

                        <div class="col-md-1">
                        </div>

                        <div class="col-md-5">

                            <div class="form-group">
                                <label for="default_image" class=""><?php echo e(tr('default_image')); ?></label>
                                <input type="file" required class="form-control" id="default_image" name="default_image" accept="image/jpeg,image/png" placeholder="<?php echo e(tr('default_image')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="other_image1" class=""><?php echo e(tr('other_image1')); ?></label>
                                <input type="file" required class="form-control" id="other_image1" name="other_image1" accept="image/jpeg,image/png" placeholder="<?php echo e(tr('other_image1')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="other_image2" class=""><?php echo e(tr('other_image2')); ?></label>
                                <input type="file" required class="form-control" id="other_image2" name="other_image2" accept="image/jpeg,image/png" placeholder="<?php echo e(tr('other_image2')); ?>">
                            </div>

                            <div class="form-group">

                                <label for="datepicker" class=""><?php echo e(tr('publish_time')); ?></label>

                                <input type="text" name="publish_time" placeholder="Select the Publish Time i.e YYYY-MM-DD" class="form-control pull-right" id="datepicker">
                                
                            </div>

                            <div class="form-group">
                                <label><?php echo e(tr('duration')); ?> : </label><small> Note: Format must be HH:MM:SS</small>

                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input required type="text" name="duration" class="form-control" data-inputmask="'alias': 'hh:mm:ss'" data-mask>
                                </div>
                                <!-- /.input group -->
                            </div>

                            <!-- 1 = normal video upload -->

                            <input type="hidden" name="video_type" value="1"> 

                            <!-- 2 = Direct Server upload -->
                            
                            <input type="hidden" name="video_upload_type" value="2">



                            <div id="upload" >

                                <div class="form-group">
                                    <label for="video" class=""><?php echo e(tr('video')); ?></label>
                                    <input type="file" class="form-control" id="video" name="video" accept="video/*" placeholder="<?php echo e(tr('picture')); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="trailer_video" class=""><?php echo e(tr('trailer_video')); ?></label>
                                    <input type="file" class="form-control" id="trailer_video" name="trailer_video" accept="video/*" placeholder="<?php echo e(tr('trailer_video')); ?>">
                                </div>


                            </div>

                        </div>

                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('add_video')); ?></button>
                    </div>
                </form>
            
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">

        $(function () {

            $('form').submit(function () {
                window.onbeforeunload = null;
            });

            window.onbeforeunload = function() {
                  return "Data will be lost if you leave the page, are you sure?";
            };

            $('#category').change(function(){

                var id = $(this).val();
                var url = "<?php echo e(url('select/sub_category')); ?>";
                
                $.post(url,{ option: id },
                
                    function(data) {

                        $('#sub_category').empty(); 

                        $('#sub_category').append("<option value=''>Select Sub category</option>");

                        if(data.length != 0) {
                            document.getElementById("sub_category").disabled=false;
                        } else {
                            document.getElementById("sub_category").disabled=true;
                        }

                        $.each(data, function(index, element) {
                            $('#sub_category').append("<option value='"+ element.id +"'>" + element.name + "</option>");
                        });
                });

            });

            $('#sub_category').change(function(){

                var id = $(this).val();
                var url = "<?php echo e(url('select/genre')); ?>";
                
                $.post(url,{ option: id },
                
                    function(data) {

                        $('#genre').empty(); 

                        $('#genre').append("<option value=''>Select genre</option>");

                        if(data.length != 0) {
                            document.getElementById("genre").disabled=false;
                        } else {
                            document.getElementById("genre").disabled=true;
                        }

                        $.each(data, function(index, element) {
                            $('#genre').append("<option value='"+ element.id +"'>" + element.name + "</option>");
                        });
                });

            });

        });
    </script>


    <script src="<?php echo e(asset('admin-css/plugins/bootstrap-datetimepicker/js/moment.min.js')); ?>"></script> 

    <script src="<?php echo e(asset('admin-css/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js')); ?>"></script> 

    <script src="<?php echo e(asset('admin-css/plugins/iCheck/icheck.min.js')); ?>"></script>

    
    <script type="text/javascript">
        
        $(function () {

            $('#datepicker').datetimepicker({
                minTime: "00:00:00",
                minDate: moment(),
            });
        });
    </script>   
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>