<?php $__env->startSection('content'); ?>

<div class="login-box">
    <h4><?php echo e(tr('register')); ?></h4>
    
    <form role="form" method="POST" action="<?php echo e(url('/register')); ?>">
        
      <div class="form-group">
        <?php echo csrf_field(); ?>

        <?php if($errors->has('email') || $errors->has('name') || $errors->has('password_confirmation') ||$errors->has('password')): ?>
            <div data-abide-error="" class="alert callout">
                <p>
                    <i class="fa fa-exclamation-triangle"></i> 
                    <strong> 
                        <?php if($errors->has('email')): ?> 
                            <?php echo e($errors->first('email')); ?>

                        <?php endif; ?>

                        <?php if($errors->has('name')): ?> 
                            <?php echo e($errors->first('name')); ?>

                        <?php endif; ?>

                        <?php if($errors->has('password')): ?> 
                            <?php echo e($errors->first('password')); ?>

                        <?php endif; ?>

                        <?php if($errors->has('password_confirmation')): ?>
                            <?php echo e($errors->first('password_confirmation')); ?>

                        <?php endif; ?>

                    </strong>
                </p>
            </div>
        <?php endif; ?>
        <label for="name"><?php echo e(tr('name')); ?></label>
        <input type="text" name="name" required class="form-control" id="name">
      </div>
      <div class="form-group">
        <label for="email"><?php echo e(tr('email')); ?></label>
        <input type="email" name="email" required class="form-control" id="email">
      </div>
      <div class="form-group">
        <label for="pwd"><?php echo e(tr('password')); ?></label>
        <input type="password" name="password" required class="form-control" id="pwd">
      </div>  
      <div class="form-group">
        <label for="pwd"><?php echo e(tr('confirm_password')); ?></label>
        <input type="password" name="password_confirmation" required class="form-control" id="pwd">
      </div>                  
      <button type="submit" class="btn btn-default"><?php echo e(tr('signup')); ?></button>
    </form>                
    <p class="help"><a href="<?php echo e(route('user.login.form')); ?>"><?php echo e(tr('login')); ?></a></p>         
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.focused', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>