<?php $__env->startSection('styles'); ?>

<style type="text/css">

.navbar-form .btn { 

padding: 8px 10px;

}

h4 {

	text-transform: capitalize;
}

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="video-full-box">

<h4><?php echo e($model->heading); ?></h4>


<?= $model->description; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>