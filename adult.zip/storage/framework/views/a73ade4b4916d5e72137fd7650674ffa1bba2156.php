<div class="cat-side-box">
    <div class="box-title">
      <h3><?php echo e(tr('categories')); ?></h3>
    </div>
    
    <div class="cat-side-box-cont">

    	<?php if(count($categories) > 0): ?>
	        <?php foreach($categories as $category): ?>
	            <a href="<?php echo e(route('user.category',$category->id)); ?>"><?php echo e($category->name); ?></a>
	        <?php endforeach; ?>
        <?php else: ?>
        	<div class="text-center"><?php echo e(tr("no_result_found")); ?></div>
        <?php endif; ?>
    </div>

</div>