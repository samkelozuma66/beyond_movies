<?php $__env->startSection('title', tr('videos')); ?>

<?php $__env->startSection('content-header', tr('videos')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-video-camera"></i> <?php echo e(tr('videos')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


	<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">

            	<?php if(count($videos) > 0): ?>

	              	<table id="example1" class="table table-bordered table-striped">

						<thead>
						    <tr>
						      <th><?php echo e(tr('id')); ?></th>
						      <th><?php echo e(tr('category')); ?></th>
						      <th><?php echo e(tr('sub_category')); ?></th>
						      <th><?php echo e(tr('genre')); ?></th>
						      <th><?php echo e(tr('title')); ?></th>
						      <th><?php echo e(tr('description')); ?></th>
						      <?php if(Setting::get('theme') == 'default'): ?>
						      	<th><?php echo e(tr('slider_video')); ?></th>
						      <?php endif; ?>
						      <th><?php echo e(tr('status')); ?></th>
						      <th><?php echo e(tr('action')); ?></th>
						    </tr>
						</thead>

						<tbody>
							<?php foreach($videos as $i => $video): ?>

							    <tr>
							      	<td><?php echo e($i+1); ?></td>
							      	<td><?php echo e($video->category_name); ?></td>
							      	<td><?php echo e($video->sub_category_name); ?></td>
							      	<td><?php if($video->genre_name): ?> <?php echo e($video->genre_name); ?> <?php else: ?> - <?php endif; ?></td>
							      	<td><?php echo e(substr($video->title , 0,25)); ?>...</td>
							      	<td><?php echo e(substr($video->description , 0, 25)); ?>...</td>
							      	<?php if(Setting::get('theme') == 'default'): ?>
							      	<td>
							      		<?php if($video->is_home_slider == 0 && $video->is_approved && $video->status): ?>
							      			<a href="<?php echo e(route('admin.slider.video' , $video->video_id)); ?>"><span class="label label-danger"><?php echo e(tr('set_slider')); ?></span></a>
							      		<?php elseif($video->is_home_slider): ?>
							      			<span class="label label-success"><?php echo e(tr('slider')); ?></span>
							      		<?php else: ?>
							      			-
							      		<?php endif; ?>
							      	</td>

							      	<?php endif; ?>
							      	<td>
							      		<?php if($video->is_approved): ?>
							      			<span class="label label-success"><?php echo e(tr('approved')); ?></span>
							       		<?php else: ?>
							       			<span class="label label-warning"><?php echo e(tr('pending')); ?></span>
							       		<?php endif; ?>
							      	</td>
								    <td>
            							<ul class="admin-action btn btn-default">
											<?php if($i == 0 || $i == 1): ?>
            									<li class="dropdown">
            								<?php else: ?>
            									<li class="dropup">
            								<?php endif; ?>	
								                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  <?php echo e(tr('action')); ?> <span class="caret"></span>
								                </a>
								                <ul class="dropdown-menu">
								                  	<li role="presentation">
                                                        <?php if(Setting::get('admin_delete_control')): ?>
                                                            <a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('edit')); ?></a>
                                                        <?php else: ?>
                                                            <a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.edit.video' , array('id' => $video->video_id))); ?>"><?php echo e(tr('edit')); ?></a>
                                                        <?php endif; ?>
                                                    </li>
								                  	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="<?php echo e(route('admin.view.video' , array('id' => $video->video_id))); ?>"><?php echo e(tr('view')); ?></a></li>
								                  	<?php if($video->is_approved): ?>
								                		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.video.decline',$video->video_id)); ?>"><?php echo e(tr('decline')); ?></a></li>
								                	<?php else: ?>
								                  		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.video.approve',$video->video_id)); ?>"><?php echo e(tr('approve')); ?></a></li>
								                  	<?php endif; ?>

								                  	<li role="presentation">
								                  		<?php if(Setting::get('admin_delete_control')): ?>

									                  	 	<a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('delete')); ?></a>

									                  	<?php else: ?>
								                  			<a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure?')" href="<?php echo e(route('admin.delete.video' , array('id' => $video->video_id))); ?>"><?php echo e(tr('delete')); ?></a>
								                  		<?php endif; ?>
								                  	</li>
								                </ul>
              								</li>
            							</ul>
								    </td>
							    </tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else: ?>
					<h3 class="no-result"><?php echo e(tr('no_video_found')); ?></h3>
				<?php endif; ?>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>