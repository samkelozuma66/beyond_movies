<?php $__env->startSection('title', 'Pages'); ?>

<?php $__env->startSection('content-header', 'Pages'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
    <li class="active"><i class="fa fa-book"></i> Pages</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">

                <?php if(count($view_pages) > 0): ?>

                    <table id="example1" class="table table-bordered table-striped">

                        <thead>
                            <tr>
                              <th>#<?php echo e(tr('id')); ?></th>
                              <th><?php echo e(tr('heading')); ?></th>
                              <th><?php echo e(tr('description')); ?></th>
                              <th><?php echo e(tr('page_type')); ?></th>
                              <th><?php echo e(tr('action')); ?></th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach($view_pages as $i => $data): ?>
                    
                                <tr>
                                  <td><?php echo e($i+1); ?></td>
                                  <td><?php echo e($data->heading); ?></td>
                                  <td><?php echo e($data->description); ?></td>
                                  <td><?php echo e($data->type); ?></td>
                                  <td>
                                        <ul class="admin-action btn btn-default">
                                            <li class="dropdown">
                                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                                  Action <span class="caret"></span>
                                                </a>

                                                <ul class="dropdown-menu">
                                                   
                                                    <li role="presentation">
                                                        <a role="menuitem" tabindex="-1" href="<?php echo e(route('editPage', array('id' => $data->id))); ?>">
                                                            Edit Page
                                                        </a>
                                                    </li>

                                                    
                                                    <li role="presentation">
                                                      <?php if(Setting::get('admin_delete_control')): ?>

                                                        <a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('delete')); ?></a>

                                                       <?php else: ?>
                                                        <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure?');" href="<?php echo e(route('deletePage',array('id' => $data->id))); ?>">
                                                            Delete Page
                                                        </a>
                                                      <?php endif; ?>
                                                    </li>
                                                </ul>
                                            </li>
                                        
                                        </ul>
                                  </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <h3 class="no-result">No results found</h3>
                <?php endif; ?>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>