<?php $__env->startSection('title', tr('dashboard')."1"); ?>

<?php $__env->startSection('content-header', tr('dashboard')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="active"><i class="fa fa-dashboard"></i> <?php echo e(tr('dashboard')); ?></a></li>
<?php $__env->stopSection(); ?>

<style type="text/css">
  .center-card{
    	width: 30% !important;
	}
  .small-box .icon {
    top: 0px !important;
  }
</style>

<?php $__env->startSection('content'); ?>

	<div class="row">

		<!-- Total Users -->

		<div class="col-lg-4 col-xs-6">

          	<div class="small-box bg-green">
            	<div class="inner">
              		<h3><?php echo e($user_count); ?></h3>
              		<p><?php echo e(tr('total_users')); ?></p>
            	</div>
            	
            	<div class="icon">
              		<i class="fa fa-user"></i>
            	</div>

            	<a href="<?php echo e(route('admin.users')); ?>" class="small-box-footer">
              		<?php echo e(tr('more_info')); ?>

              		<i class="fa fa-arrow-circle-right"></i>
            	</a>
          	</div>
        </div>

		<!-- Total Moderators -->

          <div class="col-lg-4 col-xs-6">

            <div class="small-box label-primary">
                <div class="inner">
                    <h3><?php echo e($categories); ?></h3>
                    <p><?php echo e(tr('categories')); ?></p>
                </div>
                
                <div class="icon">
                    <i class="fa fa-suitcase"></i>
                </div>

                <a href="<?php echo e(route('admin.categories')); ?>" class="small-box-footer">
                    <?php echo e(tr('more_info')); ?>

                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        
        </div>


        

        <div class="col-lg-4 col-xs-6">

          	<div class="small-box bg-yellow">
            	<div class="inner">
              		<h3><?php echo e($video_count); ?></h3>
              		<p><?php echo e(tr('today_videos')); ?></p>
            	</div>
            	
            	<div class="icon">
              		<i class="fa fa-video-camera"></i>
            	</div>

            	<a href="<?php echo e(route('admin.videos')); ?>" class="small-box-footer">
              		<?php echo e(tr('more_info')); ?>

              		<i class="fa fa-arrow-circle-right"></i>
            	</a>
          	</div>
        
        </div>

      
	</div>



    <div class="row">
        <?php if(count($recent_users) > 0): ?>

        <div class="col-md-6">
              <!-- USERS LIST -->
            <div class="box box-danger">

                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(tr('latest_users')); ?></h3>

                    <div class="box-tools pull-right">
                        <!-- <span class="label label-danger">8 New Members</span> -->
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                        </button>
                    </div>
                </div>

                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <ul class="users-list clearfix">
                        <?php foreach($recent_users as $user): ?>

                            <li>
                                <img style="width:60px;height:60px" src="<?php if($user->picture): ?> <?php echo e($user->picture); ?> <?php else: ?> <?php echo e(asset('placeholder.png')); ?> <?php endif; ?>" alt="User Image">
                                <a class="users-list-name" href="<?php echo e(route('admin.view.user' , $user->id)); ?>"><?php echo e($user->name); ?></a>
                                <span class="users-list-date"><?php echo e($user->created_at->diffForHumans()); ?></span>
                            </li>

                        <?php endforeach; ?>
                    </ul>
                  <!-- /.users-list -->
                </div>
                <!-- /.box-body -->

                <div class="box-footer text-center">
                    <a href="<?php echo e(route('admin.users')); ?>" class="uppercase"><?php echo e(tr('view_all')); ?></a>
                </div>

                <!-- /.box-footer -->
            </div>

              <!--/.box -->
        </div>

        <?php endif; ?>

        <?php if(count($recent_videos) > 0): ?>
            <div class="col-md-6">
                <div class="box box-primary">

                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(tr('recent_videos')); ?></h3>

                        <div class="box-tools pull-right">

                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>

                            <button type="button" class="btn btn-box-tool" data-widget="remove">
                                <i class="fa fa-times"></i>
                            </button>
                      </div>

                    </div>

                    <!-- /.box-header -->
                    <div class="box-body">

                        <ul class="products-list product-list-in-box">
                            <?php foreach($recent_videos as $v => $video): ?>

                                <?php if($v < 5): ?>
                                    <li class="item">
                                        <div class="product-img">
                                            <img src="<?php echo e($video->default_image); ?>" alt="Product Image">
                                        </div>
                                        <div class="product-info">
                                            <a href="<?php echo e(route('admin.view.video' , array('id' => $video->admin_video_id))); ?>" class="product-title"><?php echo e(substr($video->title, 0,50)); ?>

                                                <span class="label label-warning pull-right"><?php echo e($video->duration); ?></span>
                                            </a>
                                            <span class="product-description">
                                              <?php echo e(substr($video->description , 0 , 75)); ?>

                                            </span>
                                      </div>
                                    </li>

                                <?php endif; ?>
                            <?php endforeach; ?>
                            <!-- /.item -->
                        </ul>
                    </div>

                    <!-- /.box-body -->
                    <div class="box-footer text-center">
                        <a href="<?php echo e(route('admin.videos')); ?>" class="uppercase"><?php echo e(tr('view_all')); ?></a>
                    </div>
                    <!-- /.box-footer -->
                </div>
            </div>
        <?php endif; ?>

    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>