<?php $__env->startSection('content'); ?>

    <div class="login-box">
        <h4><?php echo e(tr('login')); ?></h4>

        <form role="form" method="POST" action="<?php echo e(url('/login')); ?>">
            
            <?php echo csrf_field(); ?>


            <div class="form-group">
                <label for="email">Email address:</label>
                <input type="email" name="email" required class="form-control" id="email">
                <?php if($errors->has('email')): ?>
                    <span class="form-error"><strong><?php echo e($errors->first('email')); ?></strong></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" name="password" required class="form-control" id="pwd">
                <span class="form-error">
                    <?php if($errors->has('password')): ?>
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    <?php endif; ?>
                </span>
            </div> 

          <button type="submit" class="btn btn-default"><?php echo e(tr('login')); ?></button>
        </form>                
        <p class="help"><a href="<?php echo e(route('user.register.form')); ?>"><?php echo e(tr('new_account')); ?></a></p>
        <p class="help"><a href="<?php echo e(url('/password/reset')); ?>"><?php echo e(tr('forgot_password')); ?></a></p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.focused', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>