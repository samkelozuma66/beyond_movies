<?php $__env->startSection('content'); ?>
    
    <div class="col-md-9 col-sm-8">
        
        <div class="row">
            
            <div class="video-player">

                <div class="videoWrapper">

                    
                    <!-- Main Video Configuration -->

                    <div class="image" id="main_video_setup_error" style="display:none;">
                        <img class="error-image" src="<?php echo e(asset('error.jpg')); ?>" alt="<?php echo e(Setting::get('site_name')); ?>">
                    </div>

                    <div id="main-video-player" style="display:none"></div>

                    <?php if(!check_valid_url($video->video)): ?>
                        <div class="image" id="main_video_error" style="display:none;">
                            <img class="error-image" src="<?php echo e(asset('error.jpg')); ?>" alt="<?php echo e(Setting::get('site_name')); ?>">
                        </div>
                    <?php endif; ?>

                    <!-- Main Video Configuration END -->

                    <!-- Trailer Video Configuration START -->

                    <div class="image" id="trailer_video_setup_error" style="display: none;">
                        <img src="<?php echo e(asset('error.jpg')); ?>" class="error-image" alt="<?php echo e(Setting::get('site_name')); ?>">
                    </div>

                    <div id="trailer-video-player"></div>

                    <?php if(!check_valid_url($video->trailer_video)): ?>

                        <div class="image" id="trailer_video_error">
                            <img src="<?php echo e(asset('error.jpg')); ?>" class="error-image" alt="<?php echo e(Setting::get('site_name')); ?>">
                        </div>
                    <?php endif; ?>

                    <div class="embed-responsive embed-responsive-16by9" id="flash_error_display" style="display: none;">
                       <div style="width: 100%;background: black; color:#fff;height:350px;">
                             <div style="text-align: center;padding-top:25%">Flash is missing. Download it from <a target="_blank" href="http://get.adobe.com/flashplayer/" class="underline">Adobe</a>.</div>
                       </div>
                    </div>

                    <!-- Trailer Video Configuration END -->
                
                </div>
            </div>
            
            <div class="content">

                <div class="title">

                    <h3><?php echo e($video->title); ?> <span class="dur"><?php echo e($video->duration); ?></span></h3>

                    <form method="post" name="watch_main_video" class="watch-full-form">

                        <?php if(Auth::check()): ?>

                            <?php if(Auth::user()->user_type == 1): ?>
                                <input class="watch-full" type="submit" id="watch_main_video_button" name="submit" value="<?php echo e(tr('watch_main_video')); ?>">
                            <?php else: ?>
                                
                                <button type="button" class="btn btn-default watch-full" disabled><?php echo e(tr('watch_main_video')); ?></button>

                                <div class="modal fade cus-mod" id="paypal" role="dialog">
                                    <div class="modal-dialog">
                                    
                                      <!-- Modal content-->
                                      <div class="modal-content">

                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Please Pay to watch Full video</h4>
                                            </div>

                                            <div class="modal-body">
                                                
                                                <a href="#" class="btn btn-info"><?php echo e(tr('paynow')); ?></a>
                                            </div>

                                      </div>
                                      
                                    </div>
                                
                                </div>

                            <?php endif; ?>
                        
                        <?php else: ?>

                            <button type="button" class="btn btn-default watch-full" data-toggle="modal" data-target="#watchMainVideo"><?php echo e(tr('watch_main_video')); ?></button>

                            <div class="modal fade cus-mod" id="watchMainVideo" role="dialog">
                                <div class="modal-dialog">
                                
                                  <!-- Modal content-->
                                  <div class="modal-content">

                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Please Login to watch Full video</h4>
                                        </div>

                                        <div class="modal-body">
                                            <!-- <p>Please <?php echo e(tr('login')); ?></p>  -->
                                            <a href="<?php echo e(route('user.login.form')); ?>" class="btn btn-info"><?php echo e(tr('login')); ?></a>
                                        </div>

                                  </div>
                                  
                                </div>
                            </div>

                        <?php endif; ?>
                    
                    </form>
                </div>

                <div class="btns">

                    <?php if(Auth::check()): ?>

                        <form name="add_to_wishlist" method="post" id="add_to_wishlist" action="<?php echo e(route('user.add.wishlist')); ?>">
                            
                            <input type="hidden" value="<?php echo e($video->admin_video_id); ?>" name="admin_video_id">
                            
                            <?php if(count(array("","")) == 1): ?>
                                
                                <input type="hidden" id="status" value="0" name="status">
                                
                                <input type="hidden" id="wishlist_id" value="<?php echo e($wishlist_status->id); ?>" name="wishlist_id">
                                
                                <button class="add" type="submit" id="added_wishlist" style="color:#DDD;background-color:#cb0000"><?php echo e(tr('added')); ?></button>
                            <?php else: ?>

                                <input type="hidden" id="status" value="1" name="status">
                                
                                <input type="hidden" id="wishlist_id" value="" name="wishlist_id">

                                <button type="submit" id="added_wishlist" class="add">+ <?php echo e(tr('add_to')); ?> <?php echo e(tr('wishlist')); ?></button>

                            <?php endif; ?>
                        </form>
                    <?php else: ?>
                        <button type="button" class="add" data-toggle="modal" data-target="#AddWishList">+ <?php echo e(tr('add_to')); ?> <?php echo e(tr('wishlist')); ?><i class="fa fa-heart"></i></button>

                        <div class="modal fade cus-mod" id="AddWishList" role="dialog">
                            <div class="modal-dialog">
                            
                              <!-- Modal content-->
                              <div class="modal-content">

                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Please login</h4>
                                    </div>

                                    <div class="modal-body">
                                         
                                        <a href="<?php echo e(route('user.login.form')); ?>" class="btn btn-info"><?php echo e(tr('login')); ?></a>
                                    </div>
                              </div>
                              
                            </div>
                        </div>
                    <?php endif; ?>

                    <a href="http://www.facebook.com/sharer.php?u=<?php echo e(route('user.single',$video->admin_video_id)); ?>" target="_blank"  class="fb-share"><?php echo e(tr('share_on_fb')); ?></a>  
                    <a href="http://twitter.com/share?text=<?php echo e($video->title); ?>...&url=<?php echo e(route('user.single',$video->admin_video_id)); ?>" target="_blank" class="gp-share"><?php echo e(tr('share_on_twitter')); ?></a>
                
                </div>

                <div>
                    <p class="des"><?php echo e($video->description); ?></p>
                </div>

                <?php if(Auth::check()): ?>

                    <div class="command-box">
                        <form method="post" id="comment_sent" name="comment_sent" action="<?php echo e(route('user.add.comment')); ?>">
                            <div class="form-group">
                                <input type="hidden" value="<?php echo e($video->admin_video_id); ?>" name="admin_video_id">
                                <label for="email"><?php echo e(tr('add_comment_msg')); ?> :</label>
                                <textarea id="comment" required style="resize:none" name="comments" placeholder="<?php echo e(tr('add_comment_msg')); ?>" class="form-control"></textarea>
                            </div>
                            <div class="text-right"> 
                                <input type="submit" class="btn btn-default" name="submit" value="send">                     
                            </div>
                        </form>
                    </div>

                <?php endif; ?>

                <?php if(count($comments) > 0): ?>
              
                    <p class="show-comments-text">More <?php echo e(tr('comments')); ?></p>

                    <span id="new-comment"></span>

                    <?php foreach($comments as $c => $comment): ?>

                        <?php if($c > 2): ?>
                            <div class="show-comments-content"> 
                        <?php endif; ?>

                            <div class="com-list">
                                <div class="com-img">
                                    <img src="<?php echo e($comment->picture); ?>">
                                </div>
                                
                                <div class="com-detail">
                                    <h5><?php echo e($comment->username); ?></h5>
                                    <h6><?php echo e($comment->created_at->diffForHumans()); ?></h6>
                                    <p><?php echo e($comment->comment); ?></p>
                                </div>
                            </div>

                        <?php if($c > 2): ?>
                            </div>
                        <?php endif; ?>

                    <?php endforeach; ?>

                <?php else: ?>

                    <span id="new-comment" style="margin-top:10px"></span>
                <?php endif; ?>
            
            </div>

        </div>

        <div class="row">
            <div class="video-full-box single">
                <div class="box-title">
                    <h3><?php echo e(tr('recent_videos')); ?></h3>
                </div>

                <?php foreach($recent_videos as $recent_video): ?>

                <div class="video-box">
                     <a href="<?php echo e(route('user.single' , $recent_video->admin_video_id)); ?>">
                        <?php 
                        $video_imagess = get_video_image($recent_video->admin_video_id); 
                        ?>

                        <?php if($video_imagess->count() == 0): ?>
                            <img class="first" src="<?php echo e($recent_video->default_image); ?>"><!-- main image -->
                            <img class="second" src="<?php echo e($recent_video->default_image); ?>"><!-- main image -->
                            <img class="third" src="<?php echo e($recent_video->default_image); ?>"><!-- main image -->
                        <?php else: ?>
                        <?php foreach($video_imagess as $video_image): ?>

                            <?php if($video_image->position == 2): ?>
                                <img class="first" src="<?php echo e($video_image->image); ?>"><!-- last -->
                            <?php else: ?>
                                <img class="third" src="<?php echo e($video_image->image); ?>"><!-- second image -->
                            <?php endif; ?>
                            <img class="second" src="<?php echo e($recent_video->default_image); ?>"><!-- main image -->
                        <?php endforeach; ?>
                        
                        <?php endif; ?>
                        <span class="time"><?php echo e($recent_video->duration); ?></span>
                        <h5 class="video-title"><?php echo e($recent_video->title); ?></h5>
                    </a>
                </div>

                <?php endforeach; ?>

            </div>
        
        </div>

    </div>

    <div class="col-md-3 col-sm-4">
        <div class="row sidebar">
            <div class="video-full-box">

                <div class="box-title">
                  <h3><?php echo e(tr('suggestions')); ?></h3>
                </div>

                <?php foreach($suggestions as $suggestion): ?>

                <div class="video-box">
                     <a href="<?php echo e(route('user.single' , $suggestion->admin_video_id)); ?>">
                        <?php 
                        $video_images = get_video_image($suggestion->admin_video_id); 
                        ?>

                        <?php if($video_images->count() == 0): ?>
                            <img class="first" src="<?php echo e($suggestion->default_image); ?>"><!-- main image -->
                            <img class="second" src="<?php echo e($suggestion->default_image); ?>"><!-- main image -->
                            <img class="third" src="<?php echo e($suggestion->default_image); ?>"><!-- main image -->
                        <?php else: ?>

                        <?php foreach($video_images as $video_image): ?>

                            <?php if($video_image->position == 2): ?>
                                <img class="first" src="<?php echo e($video_image->image); ?>"><!-- last -->
                            <?php else: ?>
                                <img class="third" src="<?php echo e($video_image->image); ?>"><!-- second image -->
                            <?php endif; ?>
                            <img class="second" src="<?php echo e($suggestion->default_image); ?>"><!-- main image -->
                        <?php endforeach; ?>
                        
                        <?php endif; ?>
                        <span class="time"><?php echo e($suggestion->duration); ?></span>
                        <h5 class="video-title"><?php echo e($suggestion->title); ?></h5>
                    </a>
                </div>

                <?php endforeach; ?>


            </div>
        </div>
    
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('jwplayer/jwplayer.js')); ?>"></script>

    <script>jwplayer.key="<?php echo e(Setting::get('JWPLAYER_KEY')); ?>";</script>

    <script type="text/javascript">
        
        jQuery(document).ready(function(){


         // Opera 8.0+
            
            var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
            // Firefox 1.0+
            var isFirefox = typeof InstallTrigger !== 'undefined';
            // At least Safari 3+: "[object HTMLElementConstructor]"
            var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
            // Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            // Chrome 1+
            var isChrome = !!window.chrome && !!window.chrome.webstore;
            // Blink engine detection
            var isBlink = (isChrome || isOpera) && !!window.CSS;

            <?php if($trailer_video): ?>

                jQuery('#trailer_video_setup_error').hide();
                jQuery('#main_video_setup_error').hide();

                if(isOpera || isSafari) {

                    jQuery('#trailer_video_setup_error').show();

                    confirm('The video format is not supported in this browser. Please open with some other browser.');

                } else {

                    var playerInstance = jwplayer("trailer-video-player");

                    playerInstance.setup({
                        file: "<?php echo e($trailer_video); ?>",
                        image: "<?php echo e($video->default_image); ?>",
                        width: "100%",
                        aspectratio: "16:9",
                        primary: "flash",
                    });

                    playerInstance.on('setupError', function() {

                        jQuery("#trailer-video-player").css("display", "none");
                        jQuery('#main_video_setup_error').hide();
                        jQuery('#trailer_video_setup_error').css("display", "block");

                        confirm('The video format is not supported in this browser. Please open with some other browser.');
                    
                    });


                    <?php if(!$history_status && Auth::check()): ?>

                        jwplayer().on('displayClick', function(e) {
                            jQuery.ajax({
                                url: "<?php echo e(route('user.add.history')); ?>",
                                type: 'post',
                                data: {'admin_video_id' : "<?php echo e($video->admin_video_id); ?>"},
                                success: function(data) {
                                }
                            });
                            
                        });

                    <?php endif; ?>
                }

            <?php endif; ?>

            //hang on event of form with id=myform
            jQuery("form[name='add_to_wishlist']").submit(function(e) {

                //prevent Default functionality
                e.preventDefault();

                //get the action-url of the form
                var actionurl = e.currentTarget.action;

                //do your own request an handle the results
                jQuery.ajax({
                        url: actionurl,
                        type: 'post',
                        dataType: 'json',
                        data: jQuery("#add_to_wishlist").serialize(),
                        success: function(data) {
                           if(data.success == true) {

                                jQuery("#added_wishlist").html("");

                                if(data.status == 1) {
                                    jQuery('#status').val("0");

                                    jQuery('#wishlist_id').val(data.wishlist_id); 
                                    jQuery("#added_wishlist").css({'background':'#cb0000','color' : '#FFFFFF'});
                                    jQuery("#added_wishlist").append('Added <i class="fa fa-heart">');
                                } else {
                                    jQuery('#status').val("1");
                                    jQuery('#wishlist_id').val("");
                                    jQuery("#added_wishlist").css({'background':'','color' : ''});
                                    jQuery("#added_wishlist").append('+ ADD To Wishlist');
                                }
                           } else {
                                console.log('Wrong...!');
                           }
                        }
                });

            });

            $('#comment').keydown(function(event) {
                if (event.keyCode == 13) {
                    $(this.form).submit()
                    return false;
                 }
           
            });

            $("form[name='comment_sent']").on('keyup keypress keydown', function(e) {
                var keyCode = e.keyCode || e.which;
                if (keyCode === 13) { 
                    e.preventDefault();
                    return false;
                }
            });

            jQuery("form[name='comment_sent']").submit(function(e) {

                //prevent Default functionality
                e.preventDefault();

                //get the action-url of the form
                var actionurl = e.currentTarget.action;

                var comment_content = jQuery('#comment').val();

                if(comment_content != ''){

                    //do your own request an handle the results
                    jQuery.ajax({
                            url: actionurl,
                            type: 'post',
                            dataType: 'json',
                            data: jQuery("#comment_sent").serialize(),
                            success: function(data) {

                               if(data.success == true) {

                                <?php if(Auth::check()): ?>
                                    jQuery('#comment').val("");
                                    jQuery('#no_comment').hide();
                                    var comment_count = 0;
                                    var count = 0;
                                    comment_count = jQuery('#comment_count').text();
                                    var count = parseInt(comment_count) + 1;
                                    jQuery('#comment_count').text(count);
                                    jQuery('#video_comment_count').text(count);

                                    jQuery('#new-comment').prepend('<div class="com-list"><div class="com-img"><img src="<?php echo e(Auth::user()->picture); ?>" ></div><div class="com-detail"><h5><?php echo e(Auth::user()->name); ?></h5><h6>'+data.date+'</h6><p>'+data.comment.comment+'</p></div></div>');
                                <?php endif; ?>
                               } else {
                                    console.log('Wrong...!');
                               }
                            }
                    
                    });

                } else {
                    return false;
                }
            
            });

            jQuery("form[name='watch_main_video']").submit(function(e) {

                //prevent Default functionality
                e.preventDefault();

                jQuery('#watch_main_video_button').hide();

                <?php if($main_video): ?>

                    if(isOpera || isSafari) {

                        jQuery('#trailer_video_setup_error').hide();


                        var hasFlash = false;
                        try {
                            var fo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
                            if (fo) {
                                hasFlash = true;
                            }
                        } catch (e) {
                            if (navigator.mimeTypes
                                    && navigator.mimeTypes['application/x-shockwave-flash'] != undefined
                                    && navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin) {
                                hasFlash = true;
                            }
                        }

                        if (hasFlash == false) {
                            jQuery('#flash_error_display').show();
                            return false;
                        }

                        jQuery('#main-video-player').hide();
                        jQuery('#main_video_setup_error').show();

                        confirm('The video format is not supported in this browser. Please option some other browser.');

                    } else {

                        var playerInstance = jwplayer("main-video-player");

                        playerInstance.setup({
                            file: "<?php echo e($main_video); ?>",
                            image: "<?php echo e($video->default_image); ?>",
                            width: "100%",
                            aspectratio: "16:9",
                            primary: "flash",
                            controls : true,
                            "controlbar.idlehide" : false,
                            controlBarMode:'floating',
                            "controls": {
                                "enableFullscreen": false,
                                "enablePlay": false,
                                "enablePause": false,
                                "enableMute": true,
                                "enableVolume": true
                            },
                            autostart : true,
                            "sharing": {
                                "sites": ["reddit","facebook","twitter"]
                              }
                        
                        });

                        playerInstance.on('setupError', function() {

                            jQuery("#main-video-player").css("display", "none");
                           
                           
                            var hasFlash = false;
                            try {
                                var fo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
                                if (fo) {
                                    hasFlash = true;
                                }
                            } catch (e) {
                                if (navigator.mimeTypes
                                        && navigator.mimeTypes['application/x-shockwave-flash'] != undefined
                                        && navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin) {
                                    hasFlash = true;
                                }
                            }

                            if (hasFlash == false) {
                                jQuery('#flash_error_display').show();
                                return false;
                            }

                            jQuery('#trailer_video_setup_error').hide();

                            jQuery('#main_video_setup_error').css("display", "block");

                            confirm('The video format is not supported in this browser. Please option some other browser.');
                        
                        });

                        jQuery("#trailer-video-player").hide();
                        jQuery("#main-video-player").show();
                    
                    }

                <?php else: ?>
                    jQuery('#main_video_error').show();
                    jQuery('#trailer_video_error').hide();

                <?php endif; ?>

            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>