<?php $__env->startSection('title', tr('edit_category')); ?>

<?php $__env->startSection('content-header', tr('edit_category')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.categories')); ?>"><i class="fa fa-suitcase"></i> <?php echo e(tr('categories')); ?></a></li>
    <li class="active"><?php echo e(tr('edit_category')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-10">

            <div class="box box-info">

                <div class="box-header">
                </div>

                <form class="form-horizontal" action="<?php echo e(route('admin.save.category')); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <input type="hidden" name="id" value="<?php echo e($category->id); ?>">

                        <div class="form-group">
                            <label for="name" class="col-sm-1 control-label"><?php echo e(tr('name')); ?></label>
                            <div class="col-sm-10">
                                <input type="text" required class="form-control" value="<?php echo e($category->name); ?>" id="name" name="name" placeholder="Category Name">
                            </div>
                        </div>

                        <div class="form-group">

                            <label for="picture" class="col-sm-1 control-label"><?php echo e(tr('picture')); ?></label>

                            <?php if($category->picture): ?>
                                <img style="height: 90px;margin-bottom: 15px; border-radius:2em;" src="<?php echo e($category->picture); ?>">
                            <?php endif; ?>

                            <div class="col-sm-10" style="margin-left:70px !important">
                                <input type="file" class="form-control" accept="image/png,image/jpeg" id="picture" name="picture" placeholder="<?php echo e(tr('picture')); ?>">
                                 <p class="help-block">Please enter .png .jpeg .jpg images only.</p>
                            </div>
                            
                        </div>

                        <div class="checkbox">
                            <label for="picture" class="col-sm-1 control-label"></label>
                            <label>
                                <input type="checkbox" name="is_series" value="1" <?php if($category->is_series): ?> checked <?php endif; ?>> Is Tv series?
                            </label>
                        </div>

                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    </div>
                </form>
            
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>