<?php $__env->startSection('title', tr('edit_page')); ?>

<?php $__env->startSection('content-header', tr('edit_page')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('viewPages')); ?>"><i class="fa fa-book"></i> <?php echo e(tr('pages')); ?></a></li>
    <li class="active"> Edit Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">

    <div class="col-md-10">

        <div class="box box-info">

            <div class="box-header">
            </div>

            <form  action="<?php echo e(route('editPageProcess')); ?>" method="POST" enctype="multipart/form-data" role="form">

                <div class="box-body">
                    <input type="hidden" name="id" value="<?php echo e($pages->id); ?>">

                    <div class="form-group">
                        <label for="heading"><?php echo e(tr('heading')); ?></label>
                        <input type="text" class="form-control" name="heading" value="<?php echo e($pages->heading); ?>" id="heading" placeholder="Enter heading">
                    </div>

                    <div class="form-group">
                        <label for="description"><?php echo e(tr('description')); ?></label>

                        <textarea id="ckeditor" name="description" class="form-control" placeholder="Enter text ..."><?php echo e($pages->description); ?></textarea>
                        
                    </div>

                </div>

              <div class="box-footer">
                    <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                    <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
              </div>

            </form>
        
        </div>

    </div>

</div>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="http://cdn.ckeditor.com/4.5.5/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'ckeditor' );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>