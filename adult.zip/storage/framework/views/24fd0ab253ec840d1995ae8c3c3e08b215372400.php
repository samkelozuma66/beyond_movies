<?php $__env->startSection('content'); ?>

    <div class="col-md-9 col-sm-8">

        <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">

            <div class="profile">

                <?php if(Auth::user()->picture == ""): ?>
                    <img src="<?php echo e(asset('placeholder.png')); ?>">
                <?php else: ?>
                    <img src="<?php echo e(Auth::user()->picture); ?>">
                <?php endif; ?>

                <form action="<?php echo e(route('user.profile.save')); ?>" method="POST" enctype="multipart/form-data">
                    
                    <div class="form-group">
                        <label for="pro-image"><?php echo e(tr('upload')); ?> <?php echo e(tr('image')); ?>:</label>
                        <input type="file" name="picture" class="form-control" id="pro-image">
                    </div>

                    <div class="form-group">
                        <label for="name"><?php echo e(tr('name')); ?></label>
                        <input type="text" name="name" required value="<?php echo e(Auth::user()->name); ?>" class="form-control" id="name">
                    </div>

                    <?php if(Auth::user()->login_by == 'manual'): ?>
                        <div class="form-group">
                            <label for="email"><?php echo e(tr('email')); ?></label>
                            <input type="email" name="email" required value="<?php echo e(Auth::user()->email); ?>" class="form-control" id="email">
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="phone"><?php echo e(tr('mobile')); ?></label>
                        <input type="text" name="mobile" value="<?php echo e(Auth::user()->mobile); ?>" class="form-control" id="phone">
                    </div>

                    <div class="form-group">
                        <label for="address"><?php echo e(tr('description')); ?></label>
                        <textarea name="description" class="form-control" id="address"><?php echo e(Auth::user()->description); ?></textarea>                      
                    </div> 

                    <div class="form-group">
                        <label for="address"><?php echo e(tr('address')); ?></label>
                        <textarea name="address" class="form-control" id="address"><?php echo e(Auth::user()->address); ?></textarea>                      
                    </div>   

                    <button type="submit" class="btn btn-default"><?php echo e(tr('submit')); ?></button>
                
                </form>                  
                
                <?php if(Auth::user()->login_by == 'manual'): ?>

                <a class="change-pwd" href="<?php echo e(route('user.change.password')); ?>">Change Password</a>

                <?php endif; ?>

            </div>
        </div>

        <?php if(count($videos = wishlist(Auth::user()->id)) > 0): ?>

            <div class="row">
                <div class="video-full-box single">
                    
                    <div class="box-title">
                        <h3><?php echo e(tr('wishlist')); ?></h3>
                    </div>

                    <?php foreach($videos = wishlist(Auth::user()->id) as $i => $video): ?>

                    <div class="video-box">
                        <a href="<?php echo e(route('user.single' , $video->admin_video_id)); ?>">
                            <?php 
                            $video_images = get_video_image($video->admin_video_id); 
                            ?>
                            <?php if($video_images->count() == 0): ?>
                                <img class="first" src="<?php echo e($video->default_image); ?>"><!-- main image -->
                                <img class="second" src="<?php echo e($video->default_image); ?>"><!-- main image -->
                                <img class="third" src="<?php echo e($video->default_image); ?>"><!-- main image -->
                            <?php else: ?>
                              <?php foreach($video_images as $video_image): ?>

                                  <?php if($video_image->position == 2): ?>
                                      <img class="first" src="<?php echo e($video_image->image); ?>"><!-- last -->
                                  <?php else: ?>
                                      <img class="third" src="<?php echo e($video_image->image); ?>"><!-- second image -->
                                  <?php endif; ?>
                                  <img class="second" src="<?php echo e($video->default_image); ?>"><!-- main image -->
                              <?php endforeach; ?>
                              <?php endif; ?>
                            <span class="time"><?php echo e($video->duration); ?></span>
                            <h5 class="video-title"><?php echo e($video->title); ?></h5>
                        </a>

                        <a onclick="return confirm('Are you sure?');" href="<?php echo e(route('user.delete.wishlist' , array('wishlist_id' => $video->wishlist_id))); ?>" class="remove-btn">
                            <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
                        </a>
                    </div>

                    <?php endforeach; ?>
                   
                </div>
            
            </div>

        <?php endif; ?>
              
    </div>

     <?php if(count($videoss = trending()) > 0): ?>
    
    <div class="col-md-3 col-sm-4">
        <div class="row sidebar">
            <div class="video-full-box">

                <div class="box-title">
                  <h3><?php echo e(tr('trending')); ?></h3>
                </div>

                <?php foreach($videoss as $videos): ?>

                <div class="video-box">
                    <a href="<?php echo e(route('user.single' , $videos->admin_video_id)); ?>">
                        <?php 
                        $video_imagess = get_video_image($videos->admin_video_id); 
                        ?>
                        <?php if($video_imagess->count() == 0): ?>
                            <img class="first" src="<?php echo e($videos->default_image); ?>"><!-- main image -->
                            <img class="second" src="<?php echo e($videos->default_image); ?>"><!-- main image -->
                            <img class="third" src="<?php echo e($videos->default_image); ?>"><!-- main image -->
                        <?php else: ?>
                          <?php foreach($video_imagess as $video_image): ?>

                              <?php if($video_image->position == 2): ?>
                                  <img class="first" src="<?php echo e($video_image->image); ?>"><!-- last -->
                              <?php else: ?>
                                  <img class="third" src="<?php echo e($video_image->image); ?>"><!-- second image -->
                              <?php endif; ?>
                              <img class="second" src="<?php echo e($videos->default_image); ?>"><!-- main image -->

                          <?php endforeach; ?>
                        <?php endif; ?>
                        <span class="time"><?php echo e($videos->duration); ?></span>
                        <h5 class="video-title"><?php echo e($videos->title); ?></h5>
                    </a>
                </div>

                <?php endforeach; ?>

            </div>
        </div>
    </div>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>