<?php $__env->startSection('title', 'Pages'); ?>

<?php $__env->startSection('content-header', 'Pages'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
    <li class="active"><i class="fa fa-book"></i> Pages</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  	<div class="row">

	    <div class="col-md-10">

	        <div class="box box-info">

	            <div class="box-header">
	            </div>

	            <form  action="<?php echo e(route('adminPagesProcess')); ?>" method="POST" enctype="multipart/form-data" role="form">

	                <div class="box-body">

	                     <div class="form-group floating-label">
	                     	<label for="select2">Select Page Type</label>
                            <select id="select2" name="type" class="form-control">
                                <option value="about" selected="true">About Us</option>
                                <option value="terms">Terms and Condition</option>
                                <option value="privacy">Privacy</option>
                                <option value="others">Others</option>
                            </select>
                            
                        </div>

	                    <div class="form-group">
	                        <label for="heading"><?php echo e(tr('heading')); ?></label>
	                        <input type="text" class="form-control" name="heading" id="heading" placeholder="Enter heading">
	                    </div>

	                    <div class="form-group">
	                        <label for="description"><?php echo e(tr('description')); ?></label>

	                        <textarea id="ckeditor" name="description" class="form-control" placeholder="Enter text ..."></textarea>
	                        
	                    </div>

	                </div>

	              <div class="box-footer">
	                    <button type="reset" class="btn btn-danger">Cancel</button>
	                    <button type="submit" class="btn btn-success pull-right">Submit</button>
	              </div>

	            </form>
	        
	        </div>

	    </div>

	</div>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="http://cdn.ckeditor.com/4.5.5/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'ckeditor' );
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>