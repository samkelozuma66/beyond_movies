<?php $__env->startSection('title', tr('add_category')); ?>

<?php $__env->startSection('content-header', tr('add_category')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.categories')); ?>"><i class="fa fa-suitcase"></i> <?php echo e(tr('categories')); ?></a></li>
    <li class="active"><?php echo e(tr('add_category')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-10">

            <div class="box box-info">

                <div class="box-header">
                </div>

                <form class="form-horizontal" action="<?php echo e(route('admin.save.category')); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <div class="form-group">
                            <label for="name" class="col-sm-1 control-label"><?php echo e(tr('name')); ?></label>
                            <div class="col-sm-10">
                                <input type="text" required class="form-control" id="name" name="name" placeholder="Category Name">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="picture" class="col-sm-1 control-label"><?php echo e(tr('picture')); ?></label>
                            <div class="col-sm-10">
                                <input type="file" required class="form-control" id="picture" accept="image/png,image/jpeg" name="picture" placeholder="<?php echo e(tr('picture')); ?>">
                            </div>
                        </div>

                        <div class="checkbox">
                            <label for="picture" class="col-sm-1 control-label"></label>
                            <label>
                                <input type="checkbox" name="is_series" value="1"> Is Tv series?
                            </label>
                        </div>

                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    </div>
                </form>
            
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>