<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(Setting::get('site_name' , "Stream Hash")); ?></title>

        <meta name="description" content="">
        <meta name="author" content="">

        <link href="<?php echo e(asset('adult/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('adult/css/jquery-ui.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('adult/css/style.css')); ?>" rel="stylesheet">

        <link rel="shortcut icon" type="image/png" href="<?php echo e(Setting::get('site_icon' , asset('img/favicon.png'))); ?>"/>

        <style type="text/css">
            .ui-autocomplete{
              z-index: 99999;
            }
        </style>

       <?php echo Setting::get('header_scripts'); ?>

    </head>

    <body>

        <div class="container-fluid">

            <?php echo $__env->make('layouts.user.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="row page-content">

                <div class="container">
                   
                    <div class="row">

                        <?php echo $__env->yieldContent('content'); ?>

                    </div>
                
                </div>

            </div>

            <?php echo $__env->make('layouts.user.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>

        <script src="<?php echo e(asset('adult/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('adult/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('adult/js/jquery-ui.js')); ?>"></script>
        <script src="<?php echo e(asset('adult/js/scripts.js')); ?>"></script>

        <script type="text/javascript">

            jQuery(document).ready( function () {
                //autocomplete
                jQuery("#auto_complete_search").autocomplete({
                    source: "<?php echo e(route('search')); ?>",
                    minLength: 1,
                    select: function(event, ui){

                        // set the value of the currently focused text box to the correct value

                        if (event.type == "autocompleteselect"){
                            
                            // console.log( "logged correctly: " + ui.item.value );

                            var username = ui.item.value;

                            if(ui.item.value == 'View All') {

                                // console.log('View AALLLLLLLLL');

                                window.location.href = "<?php echo e(route('search', array('q' => 'all'))); ?>";

                            } else {
                                // console.log("User Submit");

                                jQuery('#auto_complete_search').val(ui.item.value);

                                jQuery('#userSearch').submit();
                            }

                        }                        
                    }      // select

                }); 

            });

        </script>

        <?php echo $__env->yieldContent('scripts'); ?>

        <?php echo Setting::get('body_scripts'); ?>

    </body>
</html>