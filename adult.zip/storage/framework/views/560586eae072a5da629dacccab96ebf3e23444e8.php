<!Doctype html>
<html class="no-js" lang="">
<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <meta name="description" content="">

    <link rel="shortcut icon" href=" <?php if(Setting::get('site_icon')): ?> <?php echo e(Setting::get('site_icon')); ?> <?php else: ?> <?php echo e(asset('favicon.png')); ?> <?php endif; ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin-css/bootstrap/css/bootstrap.min.css')); ?>">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.css')); ?>">

    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('admin-css/plugins/datatables/dataTables.bootstrap.css')); ?>">

    <?php echo $__env->yieldContent('mid-styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('admin-css/plugins/select2/select2.min.css')); ?>">

      <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('admin-css/dist/css/AdminLTE.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin-css/dist/css/skins/_all-skins.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin-css/dist/css/custom.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>

   <?php echo Setting::get('header_scripts'); ?>

</head>


<body class="hold-transition skin-blue sidebar-mini">

    <div class="wrapper">

        <?php echo $__env->make('layouts.admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layouts.admin.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">

            <section class="content-header">
                <h1><?php echo $__env->yieldContent('content-header'); ?><small><?php echo $__env->yieldContent('content-sub-header'); ?></small></h1>
                <ol class="breadcrumb"><?php echo $__env->yieldContent('breadcrumb'); ?></ol>
            </section>

            <!-- Main content -->
            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </section>

        </div>

        <!-- include('layouts.admin.footer') -->

        <!-- include('layouts.admin.left-side-bar') -->

    </div>


    <!-- jQuery 2.2.0 -->
    <script src="<?php echo e(asset('admin-css/plugins/jQuery/jQuery-2.2.0.min.js')); ?>"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="<?php echo e(asset('admin-css/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin-css/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin-css/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>

    <!-- Select2 -->
    <script src="<?php echo e(asset('admin-css/plugins/select2/select2.full.min.js')); ?>"></script>
    <!-- InputMask -->
    <script src="<?php echo e(asset('admin-css/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>

    <script src="<?php echo e(asset('admin-css/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>

    <!-- SlimScroll -->
    <script src="<?php echo e(asset('admin-css/plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('admin-css/plugins/fastclick/fastclick.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('admin-css/dist/js/app.min.js')); ?>"></script>

    <!-- jvectormap -->
    <script src="<?php echo e(asset('admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>

    <script src="<?php echo e(asset('admin-css/plugins/chartjs/Chart.min.js')); ?>"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="<?php echo e(asset('admin-css/dist/js/pages/dashboard2.js')); ?>"></script> -->

    <script src="<?php echo e(asset('admin-css/dist/js/demo.js')); ?>"></script>

    <!-- page script -->
    <script>
        $(function () {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>



    <script type="text/javascript">
        $("#<?php echo e($page); ?>").addClass("active");
        <?php if(isset($sub_page)): ?> $("#<?php echo e($sub_page); ?>").addClass("active"); <?php endif; ?>
    </script>
    
    <?php echo $__env->yieldContent('scripts'); ?>

   <?php echo Setting::get('body_scripts'); ?>

</body>

</html>
