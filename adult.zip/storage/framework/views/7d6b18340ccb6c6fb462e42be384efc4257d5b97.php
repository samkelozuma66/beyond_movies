<?php $__env->startSection('title', tr('view_history')); ?>

<?php $__env->startSection('content-header',tr('view_history')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.users')); ?>"><i class="fa fa-user"></i> <?php echo e(tr('users')); ?></a></li>
    <li class="active"> <?php echo e(tr('view_history')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">

            	<?php if(count($data) > 0): ?>

	              	<table id="example1" class="table table-bordered table-striped">

						<thead>
						    <tr>
						      <th><?php echo e(tr('id')); ?></th>
						      <th><?php echo e(tr('username')); ?></th>
						      <th><?php echo e(tr('video')); ?></th>
						      <th><?php echo e(tr('date')); ?></th>
						      <th><?php echo e(tr('action')); ?></th>
						    </tr>
						</thead>

						<tbody>

							<?php foreach($data as $i => $history): ?>

							    <tr>
							      	<td><?php echo e($i+1); ?></td>
							      	<td><?php echo e($history->username); ?></td>
							      	<td><?php echo e($history->title); ?></td>
							      	<td><?php echo e($history->date); ?></td>
								    <td>
            							<ul class="admin-action btn btn-default">

											<?php if($i == 0 || $i == 1): ?>
            									<li class="dropdown">
            								<?php else: ?>
            									<li class="dropup">
            								<?php endif; ?>	
								                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  <?php echo e(tr('action')); ?> 
								                  <span class="caret"></span>
								                </a>

								                <ul class="dropdown-menu">
								                  	<li role="presentation"><a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure?');" href="<?php echo e(route('admin.delete.history' , $history->user_history_id)); ?>"><?php echo e(tr('delete')); ?></a></li>
								                </ul>

              								</li>
            							</ul>
								    </td>
							    </tr>					

							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else: ?>
					<h3 class="no-result"><?php echo e(tr('no_history_found')); ?></h3>
				<?php endif; ?>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>