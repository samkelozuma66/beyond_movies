<?php $__env->startSection('title', tr('settings')); ?>

<?php $__env->startSection('content-header', tr('settings')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-gears"></i> <?php echo e(tr('settings')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-6">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(tr('site_settings')); ?></h3>
                </div>

                <form action="<?php echo e(route('admin.save.settings')); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">
                        <div class="form-group">
                            <label for="sitename"><?php echo e(tr('site_name')); ?></label>
                            <input type="text" class="form-control" name="site_name" value="<?php echo e(Setting::get('site_name')); ?>" id="sitename" placeholder="Enter sitename">
                        </div>

                        <!-- <div class="form-group">
                            <label for="tagname"><?php echo e(tr('tag_name')); ?></label>
                            <input type="text" class="form-control" name="tag_name" value="<?php echo e(Setting::get('tag_name')); ?>" id="tagname" placeholder="Tag Name">
                        </div> -->

                        <div class="form-group">
                            <?php if(Setting::get('site_logo')): ?>
                                <img style="height: 50px; width:75px;margin-bottom: 15px; border-radius:2em;" src="<?php echo e(Setting::get('site_logo')); ?>">
                            <?php endif; ?>

                            <label for="site_logo"><?php echo e(tr('site_logo')); ?></label>
                            <input type="file" id="site_logo" name="site_logo" accept="image/png,image/jpeg">
                            <p class="help-block">Please enter .png images only.</p>
                        </div>


                        <div class="form-group">
                            <?php if(Setting::get('site_icon')): ?>
                                <img style="height: 50px; width:75px; margin-bottom: 15px; border-radius:2em;" src="<?php echo e(Setting::get('site_icon')); ?>">
                            <?php endif; ?>
                            <label for="site_icon"><?php echo e(tr('site_icon')); ?></label>
                            <input type="file" id="site_icon" name="site_icon" accept="image/png,image/jpeg">
                            <p class="help-block">Please enter .png images only.</p>
                        </div>

                  </div>
                  <!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                  </div>
                </form>

            </div>
        </div>

        <div class="col-md-6" >
            <div class="box box-warning">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(tr('other_settings')); ?></h3>
                </div>

                <form action="<?php echo e(route('admin.save.settings')); ?>" method="POST" enctype="multipart/form-data" role="form">
                    <div class="box-body">

                        <!-- <div class="form-group">
                            <label for="streaming_url"><?php echo e(tr('streaming_url')); ?></label>
                            <input type="text" value="<?php echo e(Setting::get('streaming_url')); ?>" class="form-control" name="streaming_url" id="streaming_url" placeholder="Enter Streaming URL">
                        </div>  -->

                        <div class="form-group">
                            <label for="google_analytics"><?php echo e(tr('google_analytics')); ?></label>
                            <textarea class="form-control" id="google_analytics" name="google_analytics"><?php echo e(Setting::get('google_analytics')); ?></textarea>
                        </div>  

                        <div class="form-group">
                            <label for="google_analytics"><?php echo e(tr('header_scripts')); ?></label>
                            <textarea class="form-control" id="header_scripts" name="header_scripts"><?php echo e(Setting::get('header_scripts')); ?></textarea>
                        </div>  


                        <div class="form-group">
                            <label for="google_analytics"><?php echo e(tr('body_scripts')); ?></label>
                            <textarea class="form-control" id="body_scripts" name="body_scripts"><?php echo e(Setting::get('body_scripts')); ?></textarea>
                        </div>  


                        <!-- <div class="col-md-3">
                            <div class="form-group">
                                <label for="upload_max_size"><?php echo e(tr('max_upload_size_label')); ?></label>
                                <input type="text" class="form-control" name="upload_max_size" value="<?php echo e(Setting::get('upload_max_size')); ?>" id="upload_max_size" placeholder="<?php echo e(tr('max_upload_size_label')); ?>">
                            </div>
                        </div> -->

                        
                                     

                  </div>
                  <!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                  </div>
                </form>

            </div>
        </div>
    
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>