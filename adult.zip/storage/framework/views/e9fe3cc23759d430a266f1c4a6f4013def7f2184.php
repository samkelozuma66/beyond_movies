
<?php if(Session::has('flash_errors')): ?>
    <?php if(is_array(Session::get('flash_errors'))): ?>
        <div class="alert alert-danger" >
            <button type="button" class="close" data-dismiss="alert">×</button>
            <ul>
<?php foreach(Session::get('flash_errors') as $errors): ?>
    <?php if(is_array($errors)): ?>
    <?php foreach($errors as $error): ?>
                            <li> <?php echo e($error); ?> </li>
<?php endforeach; ?>
                    <?php else: ?>
                        <li> <?php echo e($errors); ?> </li>
<?php endif; ?>
                <?php endforeach; ?>
            </ul>
        </div>
<?php else: ?>
        <div class="alert alert-danger" >
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(Session::get('flash_errors')); ?>

        </div>
<?php endif; ?>
<?php endif; ?>

<?php if(Session::has('flash_error')): ?>
    <div class="alert alert-danger" 
        <button type="button" class="close" data-dismiss="alert">×</button>
        <?php echo e(Session::get('flash_error')); ?>

    </div>
<?php endif; ?>


<?php if(Session::has('flash_success')): ?>
    <div class="alert alert-success"  >
        <button type="button" class="close" data-dismiss="alert">×</button>
        <?php echo e(Session::get('flash_success')); ?>

    </div>
<?php endif; ?>
