<div class="row footer">
<div class="container">

<div class="pull-left">
<p>&copy; 2017 - <a href="<?php echo e(Setting::get('copyrights_url') ? Setting::get('copyrights_url') : url('/')); ?>"><?php echo e(Setting::get('site_name' , 'StreamHash')); ?> </a></p>

</div>

<div class="pull-right">
<?php $pages = pages();?>

<?php if(count($pages) > 0): ?>
<ul>

	<?php foreach($pages as $page): ?>
	<li><a href="<?php echo e(route('page', $page->type)); ?>"><?php echo e($page->heading); ?></a></li>&nbsp;|&nbsp; 
	<?php endforeach; ?>
</ul>
<?php endif; ?>

</div>

<div class="clearfix"></div>
</div>
</div>