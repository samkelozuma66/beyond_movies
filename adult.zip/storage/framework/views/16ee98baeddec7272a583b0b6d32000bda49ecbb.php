<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.user.category-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="video-full-box">

        <div class="box-title">
          <h3 class="main-title"><?php echo e(tr('recent_videos')); ?></h3>
        </div>

        <?php $videos = all_videos(1); ?>

        <?php if(count($videos) > 0): ?>

            <?php foreach($videos as $video): ?>

                <div class="video-box">
                    <a href="<?php echo e(route('user.single' , $video->admin_video_id)); ?>">
                        <?php 
                        $video_images = get_video_image($video->admin_video_id); 
                        ?>
                        <?php if($video_images->count() == 0): ?>
                            <img class="first" src="<?php echo e($video->default_image); ?>"><!-- main image -->
                            <img class="second" src="<?php echo e($video->default_image); ?>"><!-- main image -->
                            <img class="third" src="<?php echo e($video->default_image); ?>"><!-- main image -->
                        <?php else: ?>
                            <?php foreach($video_images as $video_image): ?>

                                <?php if($video_image->position == 2): ?>
                                    <img class="first" src="<?php echo e($video_image->image); ?>"><!-- last -->
                                <?php else: ?>
                                    <img class="third" src="<?php echo e($video_image->image); ?>"><!-- second image -->
                                <?php endif; ?>
                                <img class="second" src="<?php echo e($video->default_image); ?>"><!-- main image -->
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <span class="time"><?php echo e($video->duration); ?></span>
                        <h5 class="video-title"><?php echo e($video->title); ?></h5>
                    </a>
                
                </div>

            <?php endforeach; ?>

            <div align="right" id="paglink"><?php echo $videos->links(); ?></div>

        <?php else: ?>

            <br>
            
            <div class="text-center"><?php echo e(tr('no_result_found')); ?></div>

        <?php endif; ?>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>