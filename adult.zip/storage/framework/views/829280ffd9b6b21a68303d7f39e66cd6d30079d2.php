<?php $__env->startSection('content'); ?>
<div class="video-full-box">
    <div class="box-title">
      <h3><?php echo e(tr('categories')); ?></h3>
    </div>

    <?php if(count($categories) > 0): ?>
      <?php foreach($categories as $category): ?>
      <div class="video-box">
        <a href="<?php echo e(route('user.category',$category->id)); ?>">
          <img src="<?php echo e($category->picture); ?>">
          <span class="time"><?php echo e(category_video_count($category->id)); ?> Videos</span>
          <h5 class="video-title cat"><?php echo e($category->name); ?></h5>
        </a>
      </div>
      <?php endforeach; ?>
    <?php else: ?>

      <br>

      <div class="text-left"><?php echo e(tr("no_result_found")); ?></div>

    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>