<div class="top-fix">
            
    <div class="row top-nav">

    	<?php if(Auth::check()): ?>
          <div class="container nav-pad">            
            <div class="dropdown">
              <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" data-hover="dropdown">
               <?php if(Auth::check()): ?> <?php echo e(Auth::user()->name); ?> <?php else: ?> User <?php endif; ?> <span class="caret"></span>
              </button>
              <ul class="dropdown-menu dropdown-menu-right">
                <li><a href="<?php echo e(route('user.profile')); ?>"><?php echo e(tr('profile')); ?></a></li>
                <li><a href="<?php echo e(route('user.wishlist')); ?>"><?php echo e(tr('wishlist')); ?></a></li>                
                <li>
                	<a href="<?php echo e(route('user.delete.account')); ?>" <?php if(Auth::user()->login_by != 'manual'): ?> onclick="return confirm('Are you sure? . Once you deleted account, you will lose your history and wishlist details.')" <?php endif; ?>>
                        <i class="fa fa-trash"></i><?php echo e(tr('delete_account')); ?>

                    </a>

                </li>  

                <li><a href="<?php echo e(route('user.logout')); ?>"><?php echo e(tr('logout')); ?></a></li>                
              </ul>
            </div>  
          </div>

        <?php else: ?> 

      	<div class="container nav-pad">
	        <a href="<?php echo e(route('user.login.form')); ?>"><?php echo e(tr('login')); ?></a>  
	        <a href="<?php echo e(route('user.register.form')); ?>"><?php echo e(tr('register')); ?></a>  
      	</div>

      	<?php endif; ?>
    
    </div>

    <div class="row main-nav">

      	<nav class="navbar navbar-default" role="navigation">

	        <div class="container nav-pad">
	          	<!-- Brand and toggle get grouped for better mobile display -->
	          	<div class="navbar-header">
		            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		              <span class="sr-only">Toggle navigation</span>
		              <span class="icon-bar"></span>
		              <span class="icon-bar"></span>
		              <span class="icon-bar"></span>
		            </button>
		            <a class="navbar-brand" href="<?php echo e(route('user.dashboard')); ?>"><img src="<?php echo e(Setting::get('site_logo' , asset('logo.png'))); ?>"></a>
	          	</div>

	          	<!-- Collect the nav links, forms, and other content for toggling -->
	          	
	          	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

		            <ul class="nav navbar-nav navbar-left">
		              	<li id="home"><a href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(tr('videos')); ?></a></li>
		              	<li id="categories"><a href="<?php echo e(route('user.categories')); ?>"><?php echo e(tr('categories')); ?></a></li>
		              	<li id="trending"><a href="<?php echo e(route('user.trending')); ?>"><?php echo e(tr('trending')); ?></a></li>
		              	<?php if(Auth::check()): ?>
		              	<li id="profile"><a href="<?php echo e(route('user.wishlist')); ?>"><?php echo e(tr('wishlist')); ?></a></li>
		              	<?php endif; ?>
		              
		            </ul>

		            <form class="navbar-form navbar-right" role="search" id="userSearch" action="<?php echo e(route('search-all')); ?>">
		              	<div class="form-group">
		                	<input type="search" required id="auto_complete_search" class="form-control" name="key" placeholder="Search">
		              	</div>

		              	<button type="submit" class="btn btn-default">
		              		<i class="glyphicon glyphicon-search"></i>
						</button>
		            
		            </form>
	            
	          	</div>

	          	<!-- /.navbar-collapse -->

	        </div>

	        <!-- /.container-fluid -->
      	</nav>
    </div>

</div>


